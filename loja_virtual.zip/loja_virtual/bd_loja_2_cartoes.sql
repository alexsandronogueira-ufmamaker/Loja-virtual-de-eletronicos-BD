-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: bd_loja_2
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cartoes`
--

DROP TABLE IF EXISTS `cartoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cartoes` (
  `id_forma_pagamento` int NOT NULL AUTO_INCREMENT,
  `cod_cliente` int NOT NULL,
  `nome` varchar(100) NOT NULL,
  `numero_cartao` char(16) NOT NULL,
  `titular` varchar(100) NOT NULL,
  `cvv` char(3) NOT NULL,
  `mes` char(2) NOT NULL,
  `ano` char(4) NOT NULL,
  PRIMARY KEY (`id_forma_pagamento`),
  KEY `cod_cliente` (`cod_cliente`),
  CONSTRAINT `cartoes_ibfk_1` FOREIGN KEY (`cod_cliente`) REFERENCES `clientes` (`cod_cliente`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cartoes`
--

LOCK TABLES `cartoes` WRITE;
/*!40000 ALTER TABLE `cartoes` DISABLE KEYS */;
INSERT INTO `cartoes` VALUES (1,1,'Visa','4539681023456721','Ana Bezerra','381','04','2029'),(2,1,'Mastercard','5274861029384710','Ana Bezerra','822','11','2030'),(3,2,'Visa','4539123012845612','Joao Mendes','129','06','2028'),(4,3,'Elo','6362971892345123','Larissa Couto','552','09','2031'),(5,4,'Visa','4539217682345120','Marcos Ribeiro','901','03','2030'),(6,5,'Mastercard','5274987654321098','Carla Nogueira','331','07','2029'),(7,6,'Elo','6362981122334455','Fabio Teixeira','245','12','2027'),(8,7,'Visa','4539001122334455','Patricia Moraes','770','02','2032'),(9,8,'Mastercard','5274009988776655','Renan Cardoso','562','08','2031'),(10,8,'Visa','4539876543211122','Renan Cardoso','118','05','2030'),(11,9,'Elo','6362003344556677','Juliana Salles','552','10','2029'),(12,10,'Visa','4539445566778899','Thiago Torres','410','03','2032'),(13,11,'Mastercard','5274556677889900','Sandra Castro','771','01','2028'),(14,12,'Elo','6362789988776655','Diego Almeida','996','06','2030'),(15,13,'Visa','4539678899001122','Roberta Martins','303','04','2031'),(16,14,'Mastercard','5274332211009988','Victor Lima','115','09','2029'),(17,15,'Elo','6362445566788990','Aline Duarte','662','08','2032'),(18,16,'Visa','4539765544332211','Henrique Passos','887','12','2030'),(19,17,'Mastercard','5274223344556677','Camila Arruda','559','07','2028'),(20,18,'Elo','6362554433221100','Jose Barreto','774','02','2031'),(21,19,'Visa','4539123412341234','Natalia Pires','622','11','2030'),(22,20,'Mastercard','5274558899002211','Andre Vasconcelos','448','05','2029'),(23,21,'Elo','6362233411223344','Beatriz Campos','335','03','2030'),(24,22,'Visa','4539432112334455','Leonardo Rezende','552','06','2031'),(25,23,'Mastercard','5274665544332211','Clara Monteiro','772','08','2032'),(26,24,'Elo','6362334455667788','Ricardo Antunes','229','09','2028'),(27,25,'Visa','4539768899001122','Helena Sousa','105','10','2031'),(28,26,'Mastercard','5274991122113344','Gustavo Paiva','501','01','2029'),(29,27,'Elo','6362776655443322','Livia Castro','883','07','2032'),(30,28,'Visa','4539112233445566','Matheus Vidal','667','03','2030'),(31,29,'Mastercard','5274002211334455','Bruna Ferreira','901','09','2029'),(32,29,'Visa','4539887766554433','Bruna Ferreira','117','12','2031'),(33,30,'Elo','6362661122338899','Otavio Cunha','330','04','2032'),(34,12,'Visa','4539223344556677','Diego Almeida','443','02','2031'),(35,4,'Elo','6362556677889900','Marcos Ribeiro','551','11','2029'),(36,14,'Visa','4539332211223344','Victor Lima','223','06','2030'),(37,15,'Mastercard','5274552233445566','Aline Duarte','889','10','2032'),(38,2,'Elo','6362445566778890','Joao Mendes','660','01','2028'),(39,7,'Visa','4539221100998877','Patricia Moraes','337','05','2031'),(40,20,'Mastercard','5274881122335566','Andre Vasconcelos','552','03','2030');
/*!40000 ALTER TABLE `cartoes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-29 23:22:33
