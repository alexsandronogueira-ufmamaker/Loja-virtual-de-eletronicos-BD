-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: bd_loja_2
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pedidos`
--

DROP TABLE IF EXISTS `pedidos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pedidos` (
  `id_pedido` int NOT NULL AUTO_INCREMENT,
  `cod_cliente` int NOT NULL,
  `data` datetime NOT NULL,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY (`id_pedido`),
  KEY `cod_cliente` (`cod_cliente`),
  CONSTRAINT `pedidos_ibfk_1` FOREIGN KEY (`cod_cliente`) REFERENCES `clientes` (`cod_cliente`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedidos`
--

LOCK TABLES `pedidos` WRITE;
/*!40000 ALTER TABLE `pedidos` DISABLE KEYS */;
INSERT INTO `pedidos` VALUES (1,12,'2024-01-14 10:22:11','pendente'),(2,3,'2024-02-05 16:35:44','entregue'),(3,28,'2024-03-22 09:11:03','processando'),(4,7,'2024-02-11 14:50:29','enviado'),(5,19,'2024-04-08 08:44:55','entregue'),(6,25,'2024-01-29 11:12:37','cancelado'),(7,14,'2024-03-02 17:33:10','pendente'),(8,30,'2024-02-18 13:47:59','processando'),(9,9,'2024-03-27 15:01:22','entregue'),(10,1,'2024-01-03 09:55:12','pendente'),(11,16,'2024-04-14 18:23:31','enviado'),(12,2,'2024-05-01 07:42:00','pendente'),(13,11,'2024-03-15 10:29:41','entregue'),(14,22,'2024-04-03 16:17:58','processando'),(15,5,'2024-02-21 12:55:02','cancelado'),(16,6,'2024-01-09 11:11:45','pendente'),(17,10,'2024-04-28 13:03:19','processando'),(18,27,'2024-03-19 09:44:50','enviado'),(19,18,'2024-02-08 15:09:13','entregue'),(20,4,'2024-05-03 08:02:22','pendente'),(21,20,'2024-03-25 17:44:33','enviado'),(22,15,'2024-02-02 14:20:01','entregue'),(23,17,'2024-04-16 09:49:54','processando'),(24,23,'2024-05-08 10:10:46','cancelado'),(25,8,'2024-01-22 16:01:19','pendente'),(26,24,'2024-03-10 13:15:58','enviado'),(27,7,'2024-04-11 11:03:41','entregue'),(28,13,'2024-02-26 07:38:50','pendente'),(29,26,'2024-03-05 12:55:44','processando'),(30,30,'2024-01-18 08:49:11','entregue'),(31,21,'2024-02-25 10:55:36','cancelado'),(32,12,'2024-03-08 15:15:02','pendente'),(33,29,'2024-04-21 14:32:48','enviado'),(34,5,'2024-03-30 16:14:20','entregue'),(35,3,'2024-01-17 11:22:33','processando'),(36,16,'2024-04-19 12:48:54','pendente'),(37,9,'2024-05-04 13:33:10','enviado'),(38,10,'2024-02-12 17:20:07','entregue'),(39,18,'2024-03-23 09:45:55','cancelado'),(40,14,'2024-01-28 10:40:41','processando'),(41,25,'2024-04-02 11:30:34','pendente'),(42,22,'2024-05-02 14:27:06','enviado'),(43,2,'2024-01-11 08:20:17','processando'),(44,11,'2024-03-29 15:34:29','entregue'),(45,4,'2024-04-26 12:22:14','pendente'),(46,15,'2024-02-09 17:30:59','entregue'),(47,28,'2024-03-12 09:51:55','processando'),(48,1,'2024-05-05 10:28:22','enviado'),(49,6,'2024-01-25 13:42:41','pendente'),(50,30,'2024-04-09 15:14:28','entregue'),(51,7,'2024-02-03 08:19:14','processando'),(52,13,'2024-03-21 11:33:42','pendente'),(53,19,'2024-04-06 13:55:00','entregue'),(54,23,'2024-02-14 10:40:36','processando'),(55,20,'2024-05-10 17:05:21','enviado'),(56,8,'2024-03-18 09:47:15','pendente'),(57,3,'2024-01-20 10:56:31','entregue'),(58,26,'2024-04-23 12:14:07','processando'),(59,12,'2024-02-19 14:55:02','cancelado'),(60,5,'2024-03-14 11:20:45','pendente'),(61,14,'2024-01-16 16:35:58','entregue'),(62,30,'2024-04-17 10:03:51','processando'),(63,22,'2024-03-06 08:22:33','pendente'),(64,10,'2024-02-28 17:39:18','enviado'),(65,6,'2024-05-07 11:14:24','entregue'),(66,9,'2024-04-24 09:26:45','pendente'),(67,18,'2024-02-04 14:33:20','processando'),(68,25,'2024-03-17 13:09:07','enviado'),(69,21,'2024-01-30 08:41:56','processando'),(70,28,'2024-04-15 16:29:51','entregue'),(71,4,'2024-03-03 11:20:12','cancelado'),(72,17,'2024-02-22 13:57:44','enviado'),(73,11,'2024-01-13 15:33:02','pendente'),(74,2,'2024-04-01 09:44:29','entregue'),(75,23,'2024-03-20 10:23:06','processando'),(76,8,'2024-02-07 12:14:55','enviado'),(77,1,'2024-05-06 15:54:12','enviado'),(78,19,'2024-03-26 14:22:59','pendente'),(79,16,'2024-04-05 17:37:10','entregue'),(80,14,'2024-01-08 11:06:24','processando'),(81,12,'2024-02-15 08:22:09','enviado'),(82,7,'2024-04-27 16:48:33','pendente'),(83,30,'2024-03-07 10:57:00','entregue'),(84,3,'2024-01-27 14:33:43','processando'),(85,5,'2024-04-22 17:52:11','enviado'),(86,9,'2024-02-29 13:10:01','entregue'),(87,20,'2024-05-09 15:18:17','processando'),(88,18,'2024-03-13 09:31:04','enviado'),(89,26,'2024-02-06 16:10:25','pendente'),(90,13,'2024-04-04 08:49:57','cancelado'),(91,8,'2024-01-10 07:33:44','processando'),(92,22,'2024-05-11 13:25:16','enviado'),(93,6,'2024-03-31 14:29:03','entregue'),(94,10,'2024-02-17 11:43:19','cancelado'),(95,17,'2024-04-13 16:00:40','processando'),(96,11,'2024-01-19 10:11:59','enviado'),(97,29,'2024-03-24 13:44:07','pendente'),(98,24,'2024-02-20 15:51:33','enviado'),(99,15,'2024-04-29 09:28:11','entregue'),(100,27,'2024-03-11 10:18:00','processando');
/*!40000 ALTER TABLE `pedidos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-29 23:22:33
