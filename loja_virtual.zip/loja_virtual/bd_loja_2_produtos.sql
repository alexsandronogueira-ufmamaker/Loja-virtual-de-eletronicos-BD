-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: bd_loja_2
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `produtos`
--

DROP TABLE IF EXISTS `produtos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produtos` (
  `id_produto` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) DEFAULT NULL,
  `modelo` varchar(100) NOT NULL,
  `preco` float DEFAULT NULL,
  `id_categoria` int DEFAULT NULL,
  `id_fornecedor` int DEFAULT NULL,
  `id_marca` int DEFAULT NULL,
  PRIMARY KEY (`id_produto`),
  KEY `id_categoria` (`id_categoria`),
  KEY `id_fornecedor` (`id_fornecedor`),
  KEY `id_marca` (`id_marca`),
  CONSTRAINT `produtos_ibfk_1` FOREIGN KEY (`id_categoria`) REFERENCES `categorias` (`id_categoria`),
  CONSTRAINT `produtos_ibfk_2` FOREIGN KEY (`id_fornecedor`) REFERENCES `fornecedores` (`id_fornecedor`),
  CONSTRAINT `produtos_ibfk_3` FOREIGN KEY (`id_marca`) REFERENCES `marcas` (`id_marca`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produtos`
--

LOCK TABLES `produtos` WRITE;
/*!40000 ALTER TABLE `produtos` DISABLE KEYS */;
INSERT INTO `produtos` VALUES (1,'Smartphone Galaxy A15','A15-128GB',1299.9,1,1,1),(2,'Smart TV LG 50','L50UHD',2499,1,2,2),(3,'Fone Sony WH-CH520','CH520BT',349.9,1,3,3),(4,'iPhone 13','IP13-128GB',3899,1,1,4),(5,'Geladeira Brastemp Frost Free','BRM44',3299,2,4,5),(6,'Microondas Electrolux','EMB38',699.9,2,4,6),(7,'Aparador de Barba Philips','QG3520',159.9,6,3,7),(8,'Notebook Dell Inspiron','INS15-11300',3499,1,2,8),(9,'Notebook Asus Vivobook','X1504ZA',2899,1,1,9),(10,'Notebook Lenovo IdeaPad','IDP3-82XA',2999,1,1,10),(11,'Xbox Series S','XSS-512GB',2199.9,1,2,11),(12,'Mouse Logitech M720','M720Tri',199.9,1,3,12),(13,'Headset HyperX Cloud Stinger','STINGER-HX',299.9,1,3,13),(14,'Notebook Acer Aspire 5','A515-57',3199,1,2,14),(15,'Furadeira Bosch GSB 450','GSB450',239.9,9,7,15),(16,'Secador Taiff Style','STY1600',169.9,6,3,16),(17,'Liquidificador Arno Power Max','PA34',189.9,2,4,17),(18,'Batedeira Mondial Premium','BM02',159.9,2,4,18),(19,'Telefone Panasonic Sem Fio','KX-TGB110',129.9,1,6,19),(20,'Tenis Nike Revolution 6','REV6-MASC',279.9,5,5,20),(21,'Livro O Pequeno Principe','LIV001',29.9,4,10,20),(22,'Livro Clean Code','LIV002',89.9,4,10,12),(23,'Livro Harry Potter e a Pedra Filosofal','LIV003',39.9,4,10,3),(24,'Cafeteira Electrolux Love Your Day','LYD10',249.9,2,4,6),(25,'Air Fryer Mondial Family','AF-30',349.9,2,4,18),(26,'Multimetro Bosch MSM100','MSM100',199.9,9,7,15),(27,'Caixa de Som Sony XB13','XB13BT',399.9,1,3,3),(28,'Monitor Dell 24','FHD-U2422',1099,1,2,8),(29,'Teclado Logitech K380','K380BT',229.9,1,3,12),(30,'Smartwatch Samsung Galaxy Watch 5','GW5-44MM',1099.9,1,1,1);
/*!40000 ALTER TABLE `produtos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-29 23:22:33
