-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: bd_loja_2
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clientes` (
  `cod_cliente` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  `cpf` varchar(20) NOT NULL,
  PRIMARY KEY (`cod_cliente`),
  UNIQUE KEY `cpf` (`cpf`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES (1,'Ana Bezerra','ana.bezerra@example.com','(11) 99812-4401','421.558.230-19'),(2,'Joao Mendes','joao.mendes@example.com','(21) 99215-7762','735.901.840-62'),(3,'Larissa Couto','larissa.couto@example.com','(31) 98744-1289','129.774.650-03'),(4,'Marcos Ribeiro','marcos.rib@example.com','(41) 99123-5521','844.662.930-40'),(5,'Carla Nogueira','carla.nogueira@example.com','(51) 99918-6654','112.904.770-28'),(6,'Fabio Teixeira','fabio.teixeira@example.com','(61) 99644-8123','520.611.390-05'),(7,'Patricia Moraes','patricia.moraes@example.com','(71) 98841-9022','908.754.210-66'),(8,'Renan Cardoso','renan.cardoso@example.com','(81) 99772-3401','355.820.140-10'),(9,'Juliana Salles','juliana.salles@example.com','(91) 99230-4410','740.903.660-31'),(10,'Thiago Torres','thiago.torres@example.com','(11) 99112-6650','500.211.880-07'),(11,'Sandra Castro','sandra.castro@example.com','(21) 99355-7291','284.197.530-22'),(12,'Diego Almeida','diego.almeida@example.com','(31) 98477-1002','630.884.920-94'),(13,'Roberta Martins','roberta.martins@example.com','(41) 99610-8821','129.540.870-08'),(14,'Victor Lima','victor.lima@example.com','(51) 99588-7120','903.771.660-60'),(15,'Aline Duarte','aline.duarte@example.com','(61) 98231-5519','712.400.290-73'),(16,'Henrique Passos','henrique.passos@example.com','(71) 98710-4452','405.680.910-59'),(17,'Camila Arruda','camila.arruda@example.com','(81) 98122-7534','290.174.330-41'),(18,'Jose Barreto','jose.barreto@example.com','(91) 99412-3398','740.884.920-06'),(19,'Natalia Pires','natalia.pires@example.com','(11) 99755-1099','350.197.530-40'),(20,'Andre Vasconcelos','andre.vasco@example.com','(21) 99845-7730','118.904.770-52'),(21,'Beatriz Campos','beatriz.campos@example.com','(31) 99210-4418','812.558.230-93'),(22,'Leonardo Rezende','leo.rezende@example.com','(41) 98423-9011','500.662.930-11'),(23,'Clara Monteiro','clara.monteiro@example.com','(51) 99612-4407','149.774.650-60'),(24,'Ricardo Antunes','ricardo.antunes@example.com','(61) 98874-2235','975.901.840-04'),(25,'Helena Sousa','helena.sousa@example.com','(71) 99914-5523','220.611.390-12'),(26,'Gustavo Paiva','gustavo.paiva@example.com','(81) 98177-6432','143.820.140-39'),(27,'Livia Castro','livia.castro@example.com','(91) 99530-1128','709.903.660-02'),(28,'Matheus Vidal','matheus.vidal@example.com','(11) 99325-8091','400.211.880-66'),(29,'Bruna Ferreira','bruna.ferreira@example.com','(21) 98792-5402','584.197.530-91'),(30,'Otavio Cunha','otavio.cunha@example.com','(31) 98412-7740','860.884.920-83');
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-29 23:22:33
