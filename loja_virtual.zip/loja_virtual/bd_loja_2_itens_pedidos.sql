-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: bd_loja_2
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `itens_pedidos`
--

DROP TABLE IF EXISTS `itens_pedidos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `itens_pedidos` (
  `id_pedido` int NOT NULL,
  `id_produto` int NOT NULL,
  `quantidade` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_pedido`,`id_produto`),
  KEY `id_produto` (`id_produto`),
  CONSTRAINT `itens_pedidos_ibfk_1` FOREIGN KEY (`id_pedido`) REFERENCES `pedidos` (`id_pedido`),
  CONSTRAINT `itens_pedidos_ibfk_2` FOREIGN KEY (`id_produto`) REFERENCES `produtos` (`id_produto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `itens_pedidos`
--

LOCK TABLES `itens_pedidos` WRITE;
/*!40000 ALTER TABLE `itens_pedidos` DISABLE KEYS */;
INSERT INTO `itens_pedidos` VALUES (1,7,3),(1,14,1),(1,29,2),(2,3,1),(2,22,2),(3,4,2),(3,17,1),(4,5,1),(4,12,3),(5,1,2),(6,9,2),(6,18,1),(7,7,4),(8,10,1),(8,25,2),(9,14,1),(10,30,1),(11,13,2),(11,27,1),(12,4,1),(12,19,2),(13,8,1),(14,16,3),(15,5,1),(15,12,1),(16,9,1),(17,13,1),(18,7,1),(18,26,2),(19,22,3),(20,3,2),(21,18,1),(21,29,1),(22,11,4),(23,1,1),(23,21,1),(24,7,2),(25,4,1),(26,16,1),(26,28,2),(27,12,2),(28,6,1),(28,30,1),(29,14,1),(30,3,3),(31,9,2),(31,19,1),(32,25,1),(33,17,2),(34,10,1),(35,2,1),(36,11,1),(37,5,1),(38,8,2),(38,13,1),(39,23,1),(40,4,2),(40,27,1),(41,14,1),(42,12,1),(43,6,1),(44,16,1),(45,18,1),(46,20,1),(47,7,3),(48,21,1),(48,30,2),(49,5,1),(50,14,2),(51,11,1),(52,19,1),(53,1,1),(54,26,1),(55,22,2),(55,29,1),(56,7,1),(57,4,1),(58,18,2),(59,20,3),(60,2,1),(61,13,1),(62,23,1),(63,11,2),(63,16,1),(64,8,1),(65,6,1),(66,17,1),(67,25,2),(68,28,1),(69,3,1),(70,18,2),(70,30,1),(71,9,1),(72,12,1),(73,4,1),(74,14,3),(75,7,1),(76,24,1),(77,15,1),(78,10,1),(79,29,2),(80,6,1),(81,17,1),(82,21,1),(83,8,1),(84,27,1),(85,3,2),(86,12,1),(87,18,1),(88,10,2),(89,4,1),(90,14,2),(91,5,1),(92,7,1),(93,1,1),(94,22,1),(95,16,1),(96,30,1),(97,25,1),(98,11,1),(99,6,1),(100,9,1);
/*!40000 ALTER TABLE `itens_pedidos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-29 23:22:32
