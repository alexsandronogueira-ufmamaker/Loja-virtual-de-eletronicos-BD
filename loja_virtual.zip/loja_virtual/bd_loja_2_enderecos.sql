-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: bd_loja_2
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `enderecos`
--

DROP TABLE IF EXISTS `enderecos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `enderecos` (
  `id_endereco` int NOT NULL AUTO_INCREMENT,
  `cod_cliente` int NOT NULL,
  `estado` varchar(50) NOT NULL,
  `cidade` varchar(50) NOT NULL,
  `bairro` varchar(50) NOT NULL,
  `logradouro` varchar(100) NOT NULL,
  `numero` varchar(10) NOT NULL,
  PRIMARY KEY (`id_endereco`),
  KEY `cod_cliente` (`cod_cliente`),
  CONSTRAINT `enderecos_ibfk_1` FOREIGN KEY (`cod_cliente`) REFERENCES `clientes` (`cod_cliente`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enderecos`
--

LOCK TABLES `enderecos` WRITE;
/*!40000 ALTER TABLE `enderecos` DISABLE KEYS */;
INSERT INTO `enderecos` VALUES (1,1,'PE','Recife','Centro','Rua Floriano Peixoto','120'),(2,1,'PE','Recife','Santo Amaro','Avenida Norte','855'),(3,2,'SP','Sao Paulo','Jardim das Flores','Rua das Acacias','45'),(4,3,'MG','Belo Horizonte','Centro','Rua Rio Branco','300'),(5,4,'RJ','Rio de Janeiro','Copacabana','Avenida Brasil','900'),(6,4,'RJ','Rio de Janeiro','Copacabana','Rua Souza Lima','112'),(7,5,'SP','Sao Paulo','Santana','Rua Dom Pedro','77'),(8,6,'MG','Contagem','Industrial','Rua Amazonas','455'),(9,7,'RN','Natal','Centro','Avenida Central','1220'),(10,8,'PE','Recife','Boa Vista','Rua Estrela Guia','88'),(11,9,'MG','Belo Horizonte','Savassi','Rua Antonio Dias','54'),(12,10,'PR','Curitiba','Centro','Rua Treze','900'),(13,11,'SP','Sao Paulo','Jardim Paulista','Rua das Oliveiras','33'),(14,12,'RS','Porto Alegre','Centro','Rua Sete de Setembro','540'),(15,13,'MG','Belo Horizonte','Planalto','Rua Horizonte Azul','199'),(16,14,'CE','Fortaleza','Meireles','Avenida Litoranea','410'),(17,15,'SP','Sao Paulo','Consolacao','Rua Frei Caneca','77'),(18,16,'AM','Manaus','Jardim Tropical','Rua Rio Verde','130'),(19,17,'RN','Natal','Petropolis','Avenida Rui Barbosa','505'),(20,18,'SE','Aracaju','Mercado','Rua Angelim','92'),(21,19,'ES','Vitoria','Centro','Rua Flor de Lis','21'),(22,20,'RS','Porto Alegre','Centro','Avenida Independencia','1880'),(23,20,'RS','Porto Alegre','Centro','Rua Ernesto Alves','320'),(24,21,'SC','Florianopolis','Praia Grande','Rua Albatroz','600'),(25,22,'GO','Goiania','Centro','Rua Canario','40'),(26,23,'SP','Sao Paulo','Jardim Europa','Rua dos Jasmins','12'),(27,24,'MG','Belo Horizonte','Funcionarios','Rua Paraiba','88'),(28,25,'BA','Salvador','Centro','Rua Bahia','190'),(29,26,'MG','Belo Horizonte','Estoril','Rua Quatro Estacoes','77'),(30,27,'RJ','Niteroi','Jardim Icarai','Rua das Palmeiras','155'),(31,28,'AL','Maceio','Centro','Rua do Comercio','299'),(32,29,'RJ','Rio de Janeiro','Leme','Avenida Atlantica','1800'),(33,29,'RJ','Rio de Janeiro','Leme','Rua Gustavo Sampaio','45'),(34,30,'PE','Recife','Pina','Rua Mar Vermelho','71'),(35,30,'PE','Recife','Boa Viagem','Rua do Sol','300'),(36,12,'RS','Porto Alegre','Centro','Rua Bento Goncalves','412'),(37,8,'MG','Contagem','Centro','Rua Santa Monica','101'),(38,3,'MG','Belo Horizonte','Santa Efigenia','Rua Acre','800'),(39,14,'CE','Fortaleza','Aldeota','Rua Iguatemi','220'),(40,7,'RN','Natal','Tirol','Rua Natalina','300');
/*!40000 ALTER TABLE `enderecos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-29 23:22:32
