-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: bd_loja_2
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `suporte_tecnico`
--

DROP TABLE IF EXISTS `suporte_tecnico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `suporte_tecnico` (
  `id_atendimento` int NOT NULL AUTO_INCREMENT,
  `id_pedido` int NOT NULL,
  `id_produto` int NOT NULL,
  `data` date DEFAULT NULL,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY (`id_atendimento`),
  KEY `id_pedido` (`id_pedido`),
  KEY `id_produto` (`id_produto`),
  CONSTRAINT `suporte_tecnico_ibfk_1` FOREIGN KEY (`id_pedido`) REFERENCES `pedidos` (`id_pedido`),
  CONSTRAINT `suporte_tecnico_ibfk_2` FOREIGN KEY (`id_produto`) REFERENCES `produtos` (`id_produto`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suporte_tecnico`
--

LOCK TABLES `suporte_tecnico` WRITE;
/*!40000 ALTER TABLE `suporte_tecnico` DISABLE KEYS */;
INSERT INTO `suporte_tecnico` VALUES (1,3,14,'2024-01-12','Aberto'),(2,7,22,'2024-01-18','Concluido'),(3,12,5,'2024-02-03','Em andamento'),(4,15,9,'2024-02-10','Aberto'),(5,18,17,'2024-02-14','Concluido'),(6,21,3,'2024-02-20','Em andamento'),(7,24,11,'2024-03-01','Aberto'),(8,27,8,'2024-03-05','Concluido'),(9,30,19,'2024-03-11','Aberto'),(10,33,7,'2024-03-21','Em andamento'),(11,36,12,'2024-03-28','Concluido'),(12,40,4,'2024-04-02','Aberto'),(13,42,16,'2024-04-10','Em andamento'),(14,45,25,'2024-04-17','Concluido'),(15,48,13,'2024-04-22','Aberto'),(16,50,6,'2024-05-01','Concluido'),(17,52,21,'2024-05-05','Em andamento'),(18,55,18,'2024-05-11','Aberto'),(19,58,29,'2024-05-19','Concluido'),(20,60,10,'2024-05-23','Em andamento'),(21,62,14,'2024-05-29','Aberto'),(22,65,2,'2024-06-03','Concluido'),(23,67,27,'2024-06-11','Aberto'),(24,70,8,'2024-06-15','Concluido'),(25,72,5,'2024-06-22','Em andamento'),(26,74,30,'2024-07-01','Aberto'),(27,75,16,'2024-07-04','Concluido'),(28,77,23,'2024-07-10','Em andamento'),(29,78,4,'2024-07-14','Aberto'),(30,79,18,'2024-07-21','Concluido'),(31,80,9,'2024-07-25','Aberto'),(32,81,12,'2024-08-01','Em andamento'),(33,82,14,'2024-08-04','Concluido'),(34,83,6,'2024-08-09','Aberto'),(35,84,20,'2024-08-13','Concluido'),(36,85,7,'2024-08-20','Em andamento'),(37,86,22,'2024-08-25','Aberto'),(38,87,3,'2024-09-02','Concluido'),(39,88,11,'2024-09-06','Em andamento'),(40,89,25,'2024-09-09','Aberto'),(41,90,19,'2024-09-15','Concluido'),(42,91,28,'2024-09-19','Em andamento'),(43,92,10,'2024-09-24','Aberto'),(44,93,14,'2024-10-01','Concluido'),(45,94,17,'2024-10-04','Aberto'),(46,95,30,'2024-10-10','Em andamento'),(47,96,21,'2024-10-15','Concluido'),(48,97,8,'2024-10-20','Aberto'),(49,98,5,'2024-10-27','Concluido'),(50,99,12,'2024-11-02','Em andamento'),(51,100,3,'2024-11-05','Aberto'),(52,15,7,'2024-11-09','Concluido'),(53,37,6,'2024-11-14','Em andamento'),(54,44,10,'2024-11-18','Aberto'),(55,52,29,'2024-11-21','Concluido'),(56,61,13,'2024-11-26','Em andamento'),(57,73,14,'2024-11-28','Aberto'),(58,88,20,'2024-12-03','Concluido'),(59,19,2,'2024-12-07','Em andamento'),(60,33,17,'2024-12-12','Aberto');
/*!40000 ALTER TABLE `suporte_tecnico` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-29 23:22:32
